define([], function () {
  'use strict';

  var AppModule = function AppModule() {};

  return AppModule;
});