define(['vb/helpers/rest'], function(Rest) 
 {
  'use strict';

  var PageModule = function PageModule() {};

   PageModule.prototype.callBIPService = function(ipordernumber) {
     
    //This is the output of steps 1 and 2, change the parameter placeholders as shown 
    const soapTemplate = `
 <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
<soap:Header/>
<soap:Body>
<pub:runReport>
<pub:reportRequest>
<pub:parameterNameValues>
<!--Zero or more repetitions:-->
<pub:item>
<pub:name>p_order_number</pub:name>
<pub:values>
<!--Zero or more repetitions:-->
<pub:item>parameter1</pub:item>
</pub:values>
</pub:item>
</pub:parameterNameValues>
<pub:reportAbsolutePath>/Custom/OM Custom/Order Acknowledgement Details Report.xdo</pub:reportAbsolutePath>
<pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
</pub:reportRequest>
<pub:appParams></pub:appParams>
</pub:runReport>
</soap:Body>
</soap:Envelope>
    `;
 const ordernumber=ipordernumber;
 //.replace('TEMPLATE', template)
    //parameters for SOAP call, likely to be provided by VB variables
   // const reportPath = "/myPath/myReport.xdo";
  //  const template = "English";
   // const locale = "US";
 
    //replace template placeholders 
    const soapBody = soapTemplate;
      soapBody.replace('parameter1', ordernumber);
    //  .replace('LOCALE', locale)
     // .replace('REPORTPATH', reportPath);
 
    //this is the service connection endpoint
    //note the hostname and authentication are defined in the service connection 
    const endpoint = 'xmlpserverServices/postExternalReportWSSService';
 
    //use the Rest helper API to make the call
    Rest.get(endpoint).body(soapBody).fetch().then(
      response => {
        //convert the response to XML and get the reportBytes
        const reportBytes = $.parseXML(response.body).getElementsByTagName("ns2:reportBytes")[0].textContent;
        displayPDF(reportBytes,"REPORT");
     });
 
    //create a new element containing the pdf data and place it in the REPORT div
    function displayPDF(pdfData, target) {
      const myPDF = document.createElement('object');
      myPDF.style.width = '100%';
      myPDF.style.height = '850pt';
      myPDF.type = 'application/pdf';
      myPDF.data = 'data:application/pdf;base64,' + pdfData;
      document.getElementById(target).appendChild(myPDF);
    }
 
  };

  return PageModule;
});
